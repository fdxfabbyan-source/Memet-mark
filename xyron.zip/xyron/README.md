# XYRON WA BOT — FAZNET
1. `npm install`  2. `cp .env.example .env` lalu isi  3. `npm start` → http://localhost:3000
Login awal: ADMIN_USER / ADMIN_PASS dari .env (default admin / admin123 — segera ganti).
Tanpa kredensial WhatsApp, app berjalan dalam mode demo (simulator di menu Chatbot).
Webhook: https://DOMAIN/webhook (GET verifikasi, POST pesan masuk).
