require('dotenv').config();
const express=require('express'),Database=require('better-sqlite3'),crypto=require('crypto');
const E=process.env,SECRET=E.SESSION_SECRET||crypto.randomBytes(32).toString('hex');
const db=new Database(E.DB_PATH||'data.db');db.pragma('journal_mode=WAL');
db.exec(`CREATE TABLE IF NOT EXISTS admins(id INTEGER PRIMARY KEY,username TEXT UNIQUE,hash TEXT,name TEXT);
CREATE TABLE IF NOT EXISTS packages(id INTEGER PRIMARY KEY,speed INTEGER UNIQUE,price INTEGER);
CREATE TABLE IF NOT EXISTS customers(id INTEGER PRIMARY KEY,name TEXT NOT NULL,phone TEXT NOT NULL,address TEXT,package_id INTEGER,install_status TEXT DEFAULT 'calon',followup_status TEXT DEFAULT 'belum',followup_date TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY,phone TEXT,direction TEXT,body TEXT,auto INTEGER DEFAULT 0,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS templates(key TEXT PRIMARY KEY,label TEXT,body TEXT);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT);
CREATE TABLE IF NOT EXISTS followups(id INTEGER PRIMARY KEY,customer_id INTEGER,note TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);`);
const get=(k,d='')=>db.prepare('SELECT value v FROM settings WHERE key=?').get(k)?.v??d;
const set=(k,v)=>db.prepare('INSERT INTO settings VALUES(?,?)ON CONFLICT(key)DO UPDATE SET value=excluded.value').run(k,String(v));
const hash=(p,s=crypto.randomBytes(16).toString('hex'))=>s+':'+crypto.scryptSync(p,s,32).toString('hex');
const check=(p,h)=>{const x=hash(p,h.split(':')[0]);return x.length==h.length&&crypto.timingSafeEqual(Buffer.from(x),Buffer.from(h))};
if(!db.prepare('SELECT 1 FROM admins').get()){db.prepare('INSERT INTO admins(username,hash,name)VALUES(?,?,?)').run(E.ADMIN_USER||'admin',hash(E.ADMIN_PASS||'admin123'),'Administrator');if(!E.ADMIN_PASS)console.warn('⚠ Login default admin/admin123 — segera ganti di Pengaturan.')}
if(!db.prepare('SELECT 1 FROM packages').get())[[65,150000],[125,165000],[175,175000],[250,215000],[350,250000]].forEach(p=>db.prepare('INSERT INTO packages(speed,price)VALUES(?,?)').run(...p));
const MENU='1. Cek Paket Internet\n2. Pendaftaran Baru\n3. Cek Coverage Area\n4. Lapor Gangguan\n5. Bicara dengan Admin';
const T={welcome:['Pesan Sambutan',`Halo! Selamat datang di *FAZNET* 👋\nBalas dengan angka menu:\n${MENU}`],
harga:['Informasi Harga','*Paket FAZNET*\n{{paket}}\n\n✔ Harga sudah termasuk PPN\n✔ Gratis biaya pemasangan sesuai ketentuan promo\n✔ Pembayaran prabayar, bayar setelah pemasangan selesai\n✔ Internet langsung aktif\n✔ Harga bulanan flat sesuai paket\n\nBalas *2* untuk daftar.'],
daftar:['Format Pendaftaran','Untuk mendaftar, kirim data berikut:\nNama: \nAlamat: \nPaket: (contoh 125)'],
coverage:['Cek Coverage','Kirim *alamat lengkap + patokan* Anda, tim kami akan mengecek jangkauan FAZNET di area tersebut.'],
gangguan:['Laporan Gangguan','Mohon maaf atas ketidaknyamanannya. Kirim: nama, alamat pemasangan, dan keluhan. Tim teknis akan segera menindaklanjuti.'],
admin:['Pesan Admin','Baik, permintaan Anda diteruskan ke admin. Mohon tunggu, kami akan membalas secepatnya.'],
offhours:['Pesan di Luar Jam Kerja','Terima kasih sudah menghubungi *FAZNET*. Saat ini di luar jam operasional. Pesan Anda kami terima dan akan dibalas saat jam kerja.'],
promo:['Pesan Promosi','Promo FAZNET: gratis biaya pemasangan sesuai ketentuan. Balas *1* untuk lihat paket.'],
followup:['Template Follow-up','Halo {{nama}}, kami dari FAZNET. Apakah Anda masih berminat berlangganan internet? Kami siap bantu proses pemasangan.']};
for(const[k,[l,b]]of Object.entries(T))db.prepare('INSERT OR IGNORE INTO templates VALUES(?,?,?)').run(k,l,b);
for(const[k,v]of Object.entries({open:'08:00',close:'21:00',bot_enabled:'1',offhours_on:'1'}))db.prepare('INSERT OR IGNORE INTO settings VALUES(?,?)').run(k,v);
const SK=['open','close','bot_enabled','offhours_on'];
const tpl=k=>db.prepare('SELECT body FROM templates WHERE key=?').get(k)?.body||'';
const rp=n=>'Rp'+n.toLocaleString('id-ID');
const mins=s=>{const[h,m]=s.split(':');return h*60+ +m};
const inHours=()=>{const n=new Date(),m=n.getHours()*60+n.getMinutes();return m>=mins(get('open'))&&m<mins(get('close'))};
const waReady=()=>!!(E.WA_ACCESS_TOKEN&&E.WA_PHONE_NUMBER_ID);
function botReply(phone,text){
 const t=text.trim().toLowerCase();
 if(get('offhours_on')==='1'&&!inHours())return tpl('offhours');
 const nm=/nama\s*:\s*(.+)/i.exec(text),ad=/alamat\s*:\s*(.+)/i.exec(text),pk=/paket\s*:\s*(\d+)/i.exec(text);
 if(nm&&ad){const p=pk&&db.prepare('SELECT id FROM packages WHERE speed=?').get(+pk[1]);
  db.prepare('INSERT INTO customers(name,phone,address,package_id)VALUES(?,?,?,?)').run(nm[1].trim().slice(0,100),phone,ad[1].trim().slice(0,300),p?.id||null);
  return '✅ Terima kasih, data pendaftaran Anda sudah kami terima. Admin akan menghubungi Anda.'}
 const k=({1:'harga',2:'daftar',3:'coverage',4:'gangguan',5:'admin'})[t]||
  (/gangguan|mati|putus|lambat|lemot|rusak|los/.test(t)?'gangguan':/admin|cs\b|operator|petugas/.test(t)?'admin':/coverage|jangkauan|area|wilayah|cover/.test(t)?'coverage':/daftar|pasang|berlangganan|langganan/.test(t)?'daftar':/paket|harga|biaya|mbps|speed|berapa/.test(t)?'harga':'welcome');
 return tpl(k).replace('{{paket}}',()=>db.prepare('SELECT * FROM packages ORDER BY speed').all().map(p=>`• ${p.speed} Mbps — ${rp(p.price)}/bulan`).join('\n'))}
async function sendWA(to,body){if(!waReady())return;const r=await fetch(`https://graph.facebook.com/v20.0/${E.WA_PHONE_NUMBER_ID}/messages`,{method:'POST',headers:{Authorization:'Bearer '+E.WA_ACCESS_TOKEN,'Content-Type':'application/json'},body:JSON.stringify({messaging_product:'whatsapp',to,type:'text',text:{body}})});if(!r.ok)throw new Error('WhatsApp API '+r.status)}
const log=(p,d,b,a=0)=>db.prepare('INSERT INTO messages(phone,direction,body,auto)VALUES(?,?,?,?)').run(p,d,b,a);
async function handle(phone,text,live){log(phone,'in',text);if(get('bot_enabled')!=='1')return null;const r=botReply(phone,text);log(phone,'out',r,1);if(live)await sendWA(phone,r).catch(x=>console.error(x.message));return r}
const sign=s=>crypto.createHmac('sha256',SECRET).update(s).digest('hex');
const cookies=q=>Object.fromEntries((q.headers.cookie||'').split(';').map(c=>c.trim().split('=')).filter(x=>x[0]));
const auth=(q,s,n)=>{const[id,exp,sig]=(cookies(q).sid||'').split('.');if(sig&&sig===sign(id+'.'+exp)&&+exp>Date.now()){q.admin=db.prepare('SELECT id,username,name FROM admins WHERE id=?').get(+id);if(q.admin)return n()}s.status(401).json({error:'Belum login'})};
const app=express();app.disable('x-powered-by');app.set('trust proxy',1);
app.use(express.json({limit:'100kb',verify:(q,_,b)=>q.rawBody=b}));
app.use((q,s,n)=>{s.set({'X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY','Referrer-Policy':'same-origin'});n()});
app.use(express.static('public'));
app.get('/webhook',(q,s)=>q.query['hub.mode']==='subscribe'&&E.WA_VERIFY_TOKEN&&q.query['hub.verify_token']===E.WA_VERIFY_TOKEN?s.send(q.query['hub.challenge']):s.sendStatus(403));
app.post('/webhook',async(q,s)=>{
 if(E.WA_APP_SECRET){const g=q.headers['x-hub-signature-256']||'',x='sha256='+crypto.createHmac('sha256',E.WA_APP_SECRET).update(q.rawBody||'').digest('hex');if(g.length!==x.length||!crypto.timingSafeEqual(Buffer.from(g),Buffer.from(x)))return s.sendStatus(401)}
 s.sendStatus(200);
 for(const en of q.body.entry||[])for(const c of en.changes||[])for(const m of c.value?.messages||[])if(m.type==='text')await handle(m.from,String(m.text.body).slice(0,2000),true)});
const tries={};
app.post('/api/login',(q,s)=>{const t=tries[q.ip]=(tries[q.ip]||[]).filter(x=>x>Date.now()-9e5);if(t.length>=10)return s.status(429).json({error:'Terlalu banyak percobaan. Coba lagi 15 menit lagi.'});
 const u=db.prepare('SELECT * FROM admins WHERE username=?').get(String(q.body.username||''));
 if(!u||!check(String(q.body.password||''),u.hash)){t.push(Date.now());return s.status(401).json({error:'Username atau password salah'})}
 const b=u.id+'.'+(Date.now()+6048e5);s.setHeader('Set-Cookie',`sid=${b}.${sign(b)}; HttpOnly; SameSite=Strict; Path=/; Max-Age=604800${E.NODE_ENV==='production'?'; Secure':''}`);s.json({ok:1})});
app.post('/api/logout',(q,s)=>{s.setHeader('Set-Cookie','sid=; HttpOnly; Path=/; Max-Age=0');s.json({ok:1})});
app.use('/api',auth);
const bad=(s,m)=>s.status(400).json({error:m});
app.get('/api/me',(q,s)=>s.json({...q.admin,wa:waReady()?'connected':'demo'}));
app.put('/api/me',(q,s)=>{const n=String(q.body.name||'').trim(),p=String(q.body.password||'');if(n.length<2)return bad(s,'Nama minimal 2 karakter');if(p&&p.length<8)return bad(s,'Password minimal 8 karakter');
 db.prepare('UPDATE admins SET name=? WHERE id=?').run(n,q.admin.id);if(p)db.prepare('UPDATE admins SET hash=? WHERE id=?').run(hash(p),q.admin.id);s.json({ok:1})});
app.get('/api/stats',(q,s)=>{const c=x=>db.prepare(x).get().n;s.json({customers:c('SELECT COUNT(*) n FROM customers'),chatIn:c("SELECT COUNT(*) n FROM messages WHERE direction='in'"),auto:c('SELECT COUNT(*) n FROM messages WHERE auto=1'),leads:c("SELECT COUNT(*) n FROM customers WHERE install_status IN('calon','dijadwalkan')"),followup:c("SELECT COUNT(*) n FROM customers WHERE followup_status='belum' AND install_status IN('calon','dijadwalkan')"),wa:waReady()?'connected':'demo',
 daily:db.prepare("SELECT date(created_at) d,COUNT(*) n FROM messages WHERE direction='in' AND created_at>=date('now','-6 days') GROUP BY d").all(),recent:db.prepare('SELECT * FROM messages ORDER BY id DESC LIMIT 8').all()})});
const cv=b=>{const n=String(b.name||'').trim(),p=String(b.phone||'').replace(/\D/g,'').replace(/^0/,'62');
 if(n.length<2)return'Nama minimal 2 karakter';if(!/^62\d{8,13}$/.test(p))return'Nomor WhatsApp tidak valid (contoh 08123456789)';
 const st=['calon','dijadwalkan','terpasang','batal'].includes(b.install_status)?b.install_status:'calon',fu=b.followup_status==='sudah'?'sudah':'belum';
 return[n.slice(0,100),p,String(b.address||'').trim().slice(0,300),b.package_id?+b.package_id:null,st,fu,/^\d{4}-\d\d-\d\d$/.test(b.followup_date||'')?b.followup_date:null]};
app.get('/api/customers',(q,s)=>{const{q:k='',status='',fu=''}=q.query;s.json(db.prepare(`SELECT c.*,p.speed FROM customers c LEFT JOIN packages p ON p.id=c.package_id WHERE (c.name LIKE @k OR c.phone LIKE @k OR c.address LIKE @k) AND (@st='' OR c.install_status=@st) AND (@fu='' OR c.followup_status=@fu) ORDER BY c.id DESC`).all({k:'%'+k+'%',st:status,fu}))});
app.post('/api/customers',(q,s)=>{const v=cv(q.body);if(typeof v==='string')return bad(s,v);s.json({id:db.prepare('INSERT INTO customers(name,phone,address,package_id,install_status,followup_status,followup_date)VALUES(?,?,?,?,?,?,?)').run(...v).lastInsertRowid})});
app.put('/api/customers/:id',(q,s)=>{const v=cv(q.body);if(typeof v==='string')return bad(s,v);db.prepare('UPDATE customers SET name=?,phone=?,address=?,package_id=?,install_status=?,followup_status=?,followup_date=? WHERE id=?').run(...v,+q.params.id);s.json({ok:1})});
app.delete('/api/customers/:id',(q,s)=>{db.prepare('DELETE FROM followups WHERE customer_id=?').run(+q.params.id);db.prepare('DELETE FROM customers WHERE id=?').run(+q.params.id);s.json({ok:1})});
app.get('/api/followups',(q,s)=>s.json(db.prepare(`SELECT c.*,p.speed,(SELECT note FROM followups WHERE customer_id=c.id ORDER BY id DESC LIMIT 1) last_note FROM customers c LEFT JOIN packages p ON p.id=c.package_id WHERE install_status IN('calon','dijadwalkan') ORDER BY followup_status='sudah',followup_date IS NULL,followup_date`).all()));
app.get('/api/customers/:id/followups',(q,s)=>s.json(db.prepare('SELECT * FROM followups WHERE customer_id=? ORDER BY id DESC').all(+q.params.id)));
app.post('/api/customers/:id/followup',(q,s)=>{const n=String(q.body.note||'').trim().slice(0,500);if(!n)return bad(s,'Catatan wajib diisi');db.prepare('INSERT INTO followups(customer_id,note)VALUES(?,?)').run(+q.params.id,n);db.prepare("UPDATE customers SET followup_status='sudah' WHERE id=?").run(+q.params.id);s.json({ok:1})});
app.get('/api/packages',(q,s)=>s.json(db.prepare('SELECT * FROM packages ORDER BY speed').all()));
app.put('/api/packages/:id',(q,s)=>{const sp=+q.body.speed,pr=+q.body.price;if(!(sp>0)||!(pr>=10000))return bad(s,'Kecepatan dan harga tidak valid (min Rp10.000)');try{db.prepare('UPDATE packages SET speed=?,price=? WHERE id=?').run(sp,pr,+q.params.id);s.json({ok:1})}catch{bad(s,'Kecepatan sudah ada')}});
app.get('/api/templates',(q,s)=>s.json(db.prepare('SELECT * FROM templates').all()));
app.put('/api/templates/:key',(q,s)=>{const b=String(q.body.body||'').trim();if(!b||b.length>3000)return bad(s,'Isi template wajib diisi (maks 3000 karakter)');db.prepare('UPDATE templates SET body=? WHERE key=?').run(b,q.params.key);s.json({ok:1})});
app.get('/api/settings',(q,s)=>s.json(Object.fromEntries(SK.map(k=>[k,get(k)]))));
app.put('/api/settings',(q,s)=>{const b=q.body;for(const k of['open','close'])if(k in b&&!/^([01]\d|2[0-3]):[0-5]\d$/.test(b[k]))return bad(s,'Format jam HH:MM');
 if('open'in b&&'close'in b&&mins(b.open)>=mins(b.close))return bad(s,'Jam buka harus sebelum jam tutup');for(const k of SK)if(k in b)set(k,b[k]);s.json({ok:1})});
app.get('/api/conversations',(q,s)=>s.json(db.prepare('SELECT m.phone,m.body,m.created_at,(SELECT name FROM customers WHERE phone=m.phone LIMIT 1) name FROM messages m WHERE id IN(SELECT MAX(id) FROM messages GROUP BY phone) ORDER BY id DESC').all()));
app.get('/api/messages/:phone',(q,s)=>s.json(db.prepare('SELECT * FROM messages WHERE phone=? ORDER BY id').all(q.params.phone.replace(/\D/g,''))));
app.post('/api/messages/send',async(q,s)=>{const p=String(q.body.phone||'').replace(/\D/g,''),t=String(q.body.text||'').trim().slice(0,2000);if(!p||!t)return bad(s,'Nomor dan pesan wajib diisi');log(p,'out',t,0);try{await sendWA(p,t);s.json({ok:1,sent:waReady()})}catch(x){bad(s,x.message)}});
app.post('/api/simulate',async(q,s)=>{const p=String(q.body.phone||'').replace(/\D/g,''),t=String(q.body.text||'').trim().slice(0,2000);if(!p||!t)return bad(s,'Nomor dan pesan wajib diisi');s.json({reply:await handle(p,t,false)})});
app.get('/api/wa',(q,s)=>s.json({ready:waReady(),env:{WA_PHONE_NUMBER_ID:!!E.WA_PHONE_NUMBER_ID,WA_BUSINESS_ACCOUNT_ID:!!E.WA_BUSINESS_ACCOUNT_ID,WA_ACCESS_TOKEN:!!E.WA_ACCESS_TOKEN,WA_VERIFY_TOKEN:!!E.WA_VERIFY_TOKEN},webhook:`${q.protocol}://${q.get('host')}/webhook`}));
app.get('/api/backup',(q,s)=>{s.attachment(`xyron-backup-${new Date().toISOString().slice(0,10)}.json`);s.json(Object.fromEntries(['packages','customers','messages','templates','settings','followups'].map(t=>[t,db.prepare(`SELECT * FROM ${t}`).all()])))});
app.listen(E.PORT||3000,()=>console.log('XYRON WA BOT berjalan di port '+(E.PORT||3000)));
